#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

struct ListInt {
    Node* head;
    ListInt() { head = NULL; }

    void insert(int value) {
        Node* newNode = new Node{value, NULL};
        if (!head) head = newNode;
        else {
            Node* temp = head;
            while (temp->next) temp = temp->next;
            temp->next = newNode;
        }
    }

    void remove(int value) {
        Node *curr = head, *prev = NULL;
        while (curr && curr->data != value) {
            prev = curr;
            curr = curr->next;
        }
        if (!curr) return;
        if (!prev) head = curr->next;
        else prev->next = curr->next;
        delete curr;
    }

    void appendList(ListInt& other) {
        if (!head) head = other.head;
        else {
            Node* temp = head;
            while (temp->next) temp = temp->next;
            temp->next = other.head;
        }
        other.head = NULL;
    }

    void print() {
        Node* temp = head;
        while (temp) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    ~ListInt() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }
};

int main() {
    ListInt list1, list2;
    cout << "Nhap 10 so nguyen: ";
    for (int i = 0, x; i < 10; i++) {
        cin >> x;
        list1.insert(x);
    }
    list1.print();
    
    int k;
    cout << "Nhap so can xoa: ";
    cin >> k;
    list1.remove(k);
    list1.print();

    cout << "Nhap 5 so nguyen cho danh sach thu 2: ";
    for (int i = 0, x; i < 5; i++) {
        cin >> x;
        list2.insert(x);
    }
    
    list1.appendList(list2);
    list1.print();
    return 0;
}
